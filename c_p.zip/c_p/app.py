from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_mail import Mail, Message
from integrations.google_calendar import create_event
from integrations.zoom import create_zoom_meeting
from integrations.slack import send_slack_message
from dotenv import load_dotenv
from pymongo import MongoClient
from datetime import datetime
import os
import random

client = MongoClient('mongodb://localhost:27017/')
db = client['meeting_app']
admin_collection = db['admins']
user_collection = db['users']
pending_users = db['pending_users']
rejected_users = db['rejected_users']
meetings_collection = db['meetings']
otp_store = {}

# Load .env variables
load_dotenv()

app = Flask(__name__)
app.secret_key = 'secret'

scheduled_meetings = [] 

# Flask-Mail configuration
app.config.update(
    MAIL_SERVER=os.getenv('MAIL_SERVER'),
    MAIL_PORT=int(os.getenv('MAIL_PORT')),
    MAIL_USE_TLS=os.getenv('MAIL_USE_TLS') == 'True',
    MAIL_USERNAME=os.getenv('MAIL_USERNAME'),
    MAIL_PASSWORD=os.getenv('MAIL_PASSWORD'),
    MAIL_DEFAULT_SENDER=os.getenv('MAIL_DEFAULT_SENDER')
)

mail = Mail(app)

def send_email(subject, recipients, body):
    msg = Message(subject, recipients=recipients)
    msg.body = body
    mail.send(msg)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        admin = admin_collection.find_one({'email': email, 'password': password})

        if admin:
            session['role'] = 'admin'  # ✅ Set the session role
            session['email'] = email
            return redirect('/home')   # ✅ Redirect to the portal page
        else:
            return render_template("admin_login.html", error="Invalid email or password")
    return render_template("admin_login.html")

@app.route('/admin-register', methods=['GET', 'POST'])
def admin_register():
    if request.method == 'POST':
        name = request.form['name']
        contact = request.form['contact']
        dob = request.form['dob']
        email = request.form['email']
        password = request.form['password']

        existing_admin = admin_collection.find_one({"email": email})
        if existing_admin:
            return "Admin already registered with this email."

        admin_collection.insert_one({
            "name": name,
            "contact": contact,
            "dob": dob,
            "email": email,
            "password": password
        })

        return render_template("index.html")  # redirect to main page after registration
    return render_template("admin_register.html")

# New route to handle initial OTP send (no DB insert yet)
@app.route('/admin-register-send-otp', methods=['POST'])
def admin_register_send_otp():
    name = request.form['name']
    contact = request.form['contact']
    dob = request.form['dob']
    email = request.form['email']
    password = request.form['password']

    if admin_collection.find_one({"email": email}):
        return jsonify({"status": "error", "message": "Email already registered."})

    otp = str(random.randint(100000, 999999))
    otp_store[email] = {
        'otp': otp,
        'data': {
            "name": name,
            "contact": contact,
            "dob": dob,
            "email": email,
            "password": password
        }
    }

    try:
        # Send OTP only to the fixed admin control email
        send_email(
            "New Admin Registration OTP",
            ["akkimiharicharan555@gmail.com"],  # <-- Fixed email
            f"""
Someone is trying to register as admin.

Email: {email}
Name: {name}
Contact: {contact}
DOB: {dob}

Your OTP for approving this registration is: {otp}
"""
        )
        return jsonify({"status": "otp_sent"})
    except Exception as e:
        return jsonify({"status": "error", "message": f"Failed to send OTP: {str(e)}"})

# New route to verify OTP and register admin
@app.route('/admin-register-verify-otp', methods=['POST'])
def admin_register_verify_otp():
    email = request.form['email']
    otp = request.form['otp']

    otp_data = otp_store.get(email)
    if not otp_data:
        return jsonify({"status": "error", "message": "OTP not requested or expired."})

    if otp_data['otp'] != otp:
        return jsonify({"status": "error", "message": "Invalid OTP."})

    admin_collection.insert_one(otp_data['data'])
    otp_store.pop(email)  # Clear OTP after use

    return jsonify({"status": "success"})

@app.route('/user-register', methods=['GET', 'POST'])
def user_register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        contact = request.form['contact']
        dob = request.form['dob']
        username = request.form['username']
        password = request.form['password']
        admin_email = request.form['admin_email']

        existing_user = user_collection.find_one({"username": username})
        if existing_user:
            return "Username already exists."

        # Save in a separate 'pending_users' collection
        pending_users.insert_one({
            "name": name,
            "email": email,
            "contact": contact,
            "dob": dob,
            "username": username,
            "password": password,
            "admin_email": admin_email,
            "status": "pending"
        })

        # Send email to admin with approve/reject links
        approve_link = f"{request.url_root}approve-user/{username}"
        reject_link = f"{request.url_root}reject-user/{username}"
        message = f"""
        A user has requested registration under your guidance.

        Username: {username}
        Name: {name}
        Email: {email}

        Approve: {approve_link}
        Reject: {reject_link}
        """
        try:
            send_email("User Registration Approval", [admin_email], message)
        except Exception as e:
            return f"Failed to send approval email: {e}"

        return "Registration request sent to admin for approval."
    
    return render_template("user_register.html")

@app.route('/approve-user/<username>')
def approve_user(username):
    user = pending_users.find_one({"username": username})
    if not user:
        return "User not found or already processed."

    user_collection.insert_one(user)
    pending_users.delete_one({"username": username})
    return f"User {username} has been approved and registered."

@app.route('/reject-user/<username>')
def reject_user(username):
    user = pending_users.find_one({"username": username})
    if not user:
        return "User not found or already processed."

    # Save rejection for reference
    rejected_users.insert_one({
        "username": user["username"],
        "admin_email": user["admin_email"],
        "reason": "Rejected by admin"
    })
    pending_users.delete_one({"username": username})
    return f"User {username} has been rejected."


@app.route('/user-login')
def user_login():
    return render_template("user_login.html")

@app.route('/user-auth', methods=['POST'], endpoint='user_auth_endpoint')
def user_auth():
    username = request.form['username']
    password = request.form['password']
    entered_admin_email = request.form['admin_email']

    user = user_collection.find_one({'username': username, 'password': password})

    if user:
        # Validate if the provided admin_email matches the one stored
        if user.get("admin_email") == entered_admin_email:
            session['role'] = 'user'
            session['user'] = username
            session['admin_email'] = entered_admin_email  # ✅ Store associated admin email
            if session['role'] == 'admin':
                return redirect('/meetings')
            else:
                return redirect('/meetings')
        else:
            return "Invalid admin email for this user."

    # Check if pending or rejected
    pending = pending_users.find_one({'username': username})
    rejected = rejected_users.find_one({'username': username})

    if pending:
        return "Your registration is pending approval."
    if rejected:
        return "Your registration was rejected by the admin."

    return "Invalid username or password"


@app.route('/admin-auth', methods=['POST'])
def admin_auth():
    email = request.form['email']
    password = request.form['password']

    admin = admin_collection.find_one({'email': email, 'password': password})
    
    
    if admin:
        otp = str(random.randint(100000, 999999))
        otp_store[email] = otp
        try:
            send_email("Your OTP Code", [email], f"Your OTP is: {otp}")
        except Exception as e:
            return f"Error sending OTP email: {e}"
        session['admin_email'] = email
        session['role'] = 'admin'
        return render_template("admin_otp.html")
    else:
        return "Invalid email or password."

@app.route('/admin-verify-otp', methods=['POST'])
def verify_admin_otp():
    entered_otp = request.form['otp']
    email = session.get('admin_email')

    if email and otp_store.get(email) == entered_otp:
        return redirect(url_for("home"))  # ✅ Proper redirect to maintain session
    return "Invalid OTP or session expired."

@app.route('/home')
def home():
    role = session.get('role', 'user')
    if role == 'admin':
        return render_template('home.html')
    else:
        return render_template('home_user.html')

@app.route('/schedule', methods=['GET'])
def show_schedule():
    return render_template('schedule.html')

@app.route("/meetings", methods=["GET"])
def meetings():
    if 'role' not in session:
        return redirect(url_for('/'))
    print("Session:", dict(session))

    role = session.get('role')
    selected_month = request.args.get('month')
    selected_year = request.args.get('year')

    query = {}

    # ✅ Use the correct field name that matches MongoDB
    if role == 'admin':
        query['admin_email'] = session['admin_email']
    elif role == 'user':
        query['admin_email'] = session['admin_email']  # user's assigned admin

    if selected_month:
        query['month'] = selected_month
    if selected_year:
        query['year'] = selected_year

    meetings = list(meetings_collection.find(query))

    months = meetings_collection.distinct('month', {'admin_email': query.get('admin_email')})
    years = meetings_collection.distinct('year', {'admin_email': query.get('admin_email')})

    return render_template(
        'meetings.html',
        meetings=meetings,
        months=months,
        years=years,
        selected_month=selected_month,
        selected_year=selected_year
    )
@app.route("/schedule", methods=["POST"])
def schedule():
    # 1. Get form data
    data = request.form
    title = data.get("title")
    date = data.get("date")
    time = data.get("time")

    # 2. Convert to datetime format for Google Calendar
    start_datetime = f"{date}T{time}:00"
    end_hour = str(int(time.split(":")[0]) + 1).zfill(2)
    end_datetime = f"{date}T{end_hour}:{time.split(':')[1]}:00"

    # 3. Create Calendar Event & Zoom Meeting
    calendar_link = create_event(title, start_datetime, end_datetime)
    zoom_link = create_zoom_meeting()

    # 4. Get currently logged-in admin
    admin_email = session.get("admin_email")
    if not admin_email:
        return "Admin not logged in", 403

    # 5. Get users registered under this admin
    users = list(user_collection.find({"admin_email": admin_email}, {"email": 1, "_id": 0}))
    user_emails = [user["email"] for user in users]

    if not user_emails:
        return "No users registered under this admin.", 404

    # 6. Send Slack message
    message = f"""
📅 *New Meeting Scheduled!*

📝 *Title:* {title}
📍 *Google Calendar:* {calendar_link}
🎥 *Zoom Link:* {zoom_link}
"""
    send_slack_message(message)

    # 7. Send Email
    email_body = f"""
Hi there,

A new meeting has been scheduled:

Title: {title}
Google Calendar: {calendar_link}
Zoom Link: {zoom_link}

Regards,
Your Collaboration Platform
"""
    try:
        send_email("New Meeting Scheduled", user_emails, email_body)
    except Exception as e:
        return f"Error sending emails: {e}"

    # 8. Store the meeting only for users under this admin
    db['meetings'].insert_one({
        "admin_email": admin_email,
        "title": title,
        "date": date,
        "time": time,
        "calendar_link": calendar_link,
        "zoom_link": zoom_link,
        "users": user_emails,
        "created_at": datetime.now()
    })

    return render_template("meeting_success.html", title=title, calendar=calendar_link, zoom=zoom_link)

if __name__ == "__main__":
    app.run(debug=True)
