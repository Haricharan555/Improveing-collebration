import os
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request

# If modifying the calendar, we need the scope
SCOPES = ['https://www.googleapis.com/auth/calendar']

def authenticate_google():
    """Authenticate and return the Google Calendar API service."""
    creds = None
    # Token file stores the user's access and refresh tokens
    if os.path.exists('token.pkl'):
        with open('token.pkl', 'rb') as token:
            creds = pickle.load(token)

    # If there's no (valid) credentials, prompt the user to log in
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        # Save the credentials for the next run
        with open('token.pkl', 'wb') as token:
            pickle.dump(creds, token)

    service = build('calendar', 'v3', credentials=creds)
    return service

def create_event(summary, start_datetime, end_datetime):
    """Create a Google Calendar event and return the link to the event."""
    service = authenticate_google()

    event = {
    'summary': 'Test Meeting',
    'location': 'Online',
    'description': 'This is a test event created via the Calendar API.',
    'start': {
        'dateTime': '2025-04-17T15:00:00+05:30',  # ISO 8601 format
        'timeZone': 'Asia/Kolkata',
    },
    'end': {
        'dateTime': '2025-04-17T16:00:00+05:30',
        'timeZone': 'Asia/Kolkata',
    },
    'attendees': [
        {'email': 'someone@example.com'},
    ],
    'reminders': {
        'useDefault': True,
    },
}


    event_result = service.events().insert(calendarId='primary', body=event).execute()
    return event_result['htmlLink']
