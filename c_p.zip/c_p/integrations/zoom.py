import requests
import json
import os
from requests.auth import _basic_auth_str
from dotenv import load_dotenv

load_dotenv()

ZOOM_ACCOUNT_ID = os.getenv("ZOOM_ACCOUNT_ID")
ZOOM_CLIENT_ID = os.getenv("ZOOM_CLIENT_ID")
ZOOM_CLIENT_SECRET = os.getenv("ZOOM_CLIENT_SECRET")
ZOOM_USER_ID = os.getenv("ZOOM_USER_ID")

def get_access_token():
    url = f"https://zoom.us/oauth/token?grant_type=account_credentials&account_id={ZOOM_ACCOUNT_ID}"
    headers = {
        "Authorization": _basic_auth_str(ZOOM_CLIENT_ID, ZOOM_CLIENT_SECRET)
    }
    response = requests.post(url, headers=headers)
    print("Access Token Response:", response.status_code, response.text)
    return response.json().get("access_token")

def create_zoom_meeting():
    token = get_access_token()
    if not token:
        print("Failed to retrieve Zoom access token.")
        return None

    headers = {
        'authorization': f"Bearer {token}",
        'content-type': "application/json"
    }

    data = {
        "topic": "Test Meeting",
        "type": 1,
        "settings": {
            "host_video": True,
            "participant_video": True
        }
    }

    response = requests.post(
        "https://api.zoom.us/v2/users/me/meetings",
        headers=headers,
        data=json.dumps(data)
    )

    if response.status_code == 201:
        return response.json().get("join_url")
    else:
        print("Zoom API Error:", response.status_code, response.text)
        return None
